<?php
//define the path to JFusion's plugins
define('JFUSION_PLUGIN_PATH',JPATH_SITE .DS.'components'.DS.'com_jfusion'.DS.'plugins');

//relative URL to JFusion's plugin dir
define('JFUSION_PLUGIN_DIR_URL','components/com_jfusion/plugins/');
?>